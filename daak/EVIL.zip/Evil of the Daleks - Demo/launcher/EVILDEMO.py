import tkinter as tk        #tkinter, gui library.
#from tkinter import ttk     #tkinter widgets.
from ctypes import windll   #Used to make text in window appear crisp.
import subprocess           #Used to launch software.
import webbrowser           #Used for help button to open webpage.

root = tk.Tk()
root.title("Evil of the Daleks - Demo")

#The following is used to make a window and place it at the center of the screen.
windowWidth = 800
windowHeight = 600
screenWidth = root.winfo_screenwidth()
screenHeight = root.winfo_screenheight()
screenCenterX = int(screenWidth/2 - windowWidth/2)
screenCenterY = int(screenHeight/2 - windowHeight/2)

root.geometry(f"{windowWidth}x{windowHeight}+{screenCenterX}+{screenCenterY}")
root.resizable(False, False)
root.iconbitmap('./launcher/appIcon.ico')

#Whether the windowed button is true.
global fullscreenSwitch
global loadConfig
fullscreenSwitch = False
loadConfig = "engine//configFullscreen.cfg"

#What follows are the functions for each button.
def launchDaak0(event):
    global loadConfig
    subprocess.run(["engine\\doomretro.exe", "-iwad", "iwad\\freedoom2.WAD", "-config", loadConfig, "-pwad", "pwad\\EVILDEMO.wad", "-noupdate"])
    root.destroy()
def hoverDaak0(event):
    backgroundCanvas.itemconfig(daak0Canvas, image=daak0ImageHover)
    backgroundCanvas.config(cursor="hand2")
def unHoverDaak0(event):
    backgroundCanvas.itemconfig(daak0Canvas, image=daak0Image)
    backgroundCanvas.config(cursor="")
    

def launchDaak1(event):
    subprocess.Popen(["engine\\doomretro.exe", "-iwad", "iwad\\freedoom2.WAD", "-pwad", "pwad\\DAAK1.wad", "-noupdate"])
    root.destroy()
def hoverDaak1(event):
    backgroundCanvas.itemconfig(daak1Canvas, image=daak1ImageHover)
    backgroundCanvas.config(cursor="hand2")
def unHoverDaak1(event):
    backgroundCanvas.itemconfig(daak1Canvas, image=daak1Image)
    backgroundCanvas.config(cursor="")


def launchDaak2(event):
    subprocess.Popen(["engine\\doomretro.exe", "-iwad", "iwad\\freedoom2.WAD", "-pwad", "pwad\\DAAK2.wad", "-noupdate"])
    root.destroy()
def hoverDaak2(event):
    backgroundCanvas.itemconfig(daak2Canvas, image=daak2ImageHover)
    backgroundCanvas.config(cursor="hand2")
def unHoverDaak2(event):
    backgroundCanvas.itemconfig(daak2Canvas, image=daak2Image)
    backgroundCanvas.config(cursor="")
    
def openWebpage(event):
    url = "https://www.freazywarr.com/daak.html"
    webbrowser.open(url)
def hoverHelp(event):
    backgroundCanvas.itemconfig(helpCanvas, image=helpImageHover)
    backgroundCanvas.config(cursor="hand2")
def unHoverHelp(event):
    backgroundCanvas.itemconfig(helpCanvas, image=helpImage)
    backgroundCanvas.config(cursor="")

def toggleWindowed(event):
    global fullscreenSwitch
    global loadConfig
    if fullscreenSwitch == False:
        backgroundCanvas.itemconfig(windowCanvas, image=windowedTrueHover)
        fullscreenSwitch = True
        loadConfig = "engine//configWindowed.cfg"
    else:
        backgroundCanvas.itemconfig(windowCanvas, image=windowedFalseHover)
        fullscreenSwitch = False
        loadConfig = "engine//configFullscreen.cfg"
def hoverWindowed(event):
    if fullscreenSwitch == False:
        backgroundCanvas.itemconfig(windowCanvas, image=windowedFalseHover)
    else:
        backgroundCanvas.itemconfig(windowCanvas, image=windowedTrueHover)
    backgroundCanvas.config(cursor="hand2")
def unHoverWindowed(event):
    if fullscreenSwitch == False:
        backgroundCanvas.itemconfig(windowCanvas, image=windowedFalse)
    else:
        backgroundCanvas.itemconfig(windowCanvas, image=windowedTrue)
    backgroundCanvas.config(cursor="")

#What follows is the content for the window.
backgroundImage = tk.PhotoImage(file = "launcher\\background.png")
headerImage = tk.PhotoImage(file = "launcher\\header.png")
subheaderImage = tk.PhotoImage(file = "launcher\\subheader.png")

    #Background and header content.
backgroundCanvas = tk.Canvas(root, width=800, height=600)
backgroundCanvas.pack(fill="both", expand=True)
backgroundCanvas.create_image(0,0, image=backgroundImage, anchor="nw")
backgroundCanvas.create_image(0,0, image=headerImage, anchor="nw")
backgroundCanvas.create_image(0,178, image=subheaderImage, anchor="nw")

    #Button content.
daak0Image = tk.PhotoImage(file = "launcher\\wad1.png")
daak0ImageHover = tk.PhotoImage(file = "launcher\\wad1Hover.png")
daak1Image = tk.PhotoImage(file = "launcher\\wad2Disabled.png")     #Temporary whilst Daak1 is being developed.
#daak1Image = tk.PhotoImage(file = "launcher\\wad2.png")
#daak1ImageHover = tk.PhotoImage(file = "launcher\\wad2Hover.png")
daak2Image = tk.PhotoImage(file = "launcher\\wad3Disabled.png")     #Temporary whilst Daak1 is being developed.
#daak2Image = tk.PhotoImage(file = "launcher\\wad3.png")
#daak2ImageHover = tk.PhotoImage(file = "launcher\\wad3Hover.png")
helpImage = tk.PhotoImage(file = "launcher\\help.png")
helpImageHover = tk.PhotoImage(file = "launcher\\helpHover.png")
windowedTrue = tk.PhotoImage(file = "launcher\\windowedTrue.png")
windowedTrueHover = tk.PhotoImage(file = "launcher\\windowedTrueHover.png")
windowedFalse = tk.PhotoImage(file = "launcher\\windowedFalse.png")
windowedFalseHover = tk.PhotoImage(file = "launcher\\windowedFalseHover.png")

daak0Canvas = backgroundCanvas.create_image(700, 250, anchor="ne", image=daak0Image)
backgroundCanvas.tag_bind(daak0Canvas, "<Button-1>", launchDaak0)
backgroundCanvas.tag_bind(daak0Canvas, "<Enter>", hoverDaak0)
backgroundCanvas.tag_bind(daak0Canvas, "<Leave>", unHoverDaak0)

daak1Canvas = backgroundCanvas.create_image(700, 320, anchor="ne", image=daak1Image)    #Currently disabled whilst in development.
#backgroundCanvas.tag_bind(daak1Canvas, "<Button-1>", launchDaak1)
#backgroundCanvas.tag_bind(daak1Canvas, "<Enter>", hoverDaak1)
#backgroundCanvas.tag_bind(daak1Canvas, "<Leave>", unHoverDaak1)

daak2Canvas = backgroundCanvas.create_image(700, 390, anchor="ne", image=daak2Image)    #Currently disabled whilst in development.
#backgroundCanvas.tag_bind(daak2Canvas, "<Button-1>", launchDaak2)
#backgroundCanvas.tag_bind(daak2Canvas, "<Enter>", hoverDaak2)
#backgroundCanvas.tag_bind(daak2Canvas, "<Leave>", unHoverDaak2)

helpCanvas = backgroundCanvas.create_image(700, 460, anchor="ne", image=helpImage)
backgroundCanvas.tag_bind(helpCanvas, "<Button-1>", openWebpage)
backgroundCanvas.tag_bind(helpCanvas, "<Enter>", hoverHelp)
backgroundCanvas.tag_bind(helpCanvas, "<Leave>", unHoverHelp)

windowCanvas = backgroundCanvas.create_image(60, 530, anchor="nw", image=windowedFalse)
backgroundCanvas.tag_bind(windowCanvas, "<Button-1>", toggleWindowed)
backgroundCanvas.tag_bind(windowCanvas, "<Enter>", hoverWindowed)
backgroundCanvas.tag_bind(windowCanvas, "<Leave>", unHoverWindowed)

# root.mainloop(), always put last. 
try:
    windll.shcore.SetProcessDpiAwareness(1) #Needed to stop text from blurring.
finally:
    root.mainloop()
